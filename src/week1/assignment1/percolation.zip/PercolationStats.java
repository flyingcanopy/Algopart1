package assignment1;

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    double res[];
    public PercolationStats(int n, int trials)
    {
        res=new double[trials];
        for(int i=0;i<trials;i++) {
            Percolation p = new Percolation(n);
            while (!p.percolates()) {
                int row = StdRandom.uniform(1, n + 1);
                int col = StdRandom.uniform(1, n + 1);
                if (!p.isOpen(row, col)) {
                    p.open(row, col);
                }

            }
           res[i]= (double)p.numberOfOpenSites() / (n*n);
        }
    }
    public double mean()
    {
       return StdStats.mean(res);
    }
    public double stddev()
    {
        return StdStats.stddev(res);

    }
    public double confidenceLo()
    {
        return mean() - ((1.96 * stddev()) / Math.sqrt(res.length));

    }
    public double confidenceHi()
    {
       return mean() + ((1.96 * stddev()) / Math.sqrt(res.length));

    }
    public static void main(String[] args)
    {
        PercolationStats ps=new PercolationStats(200,100);
        System.out.println(ps.mean());
        System.out.println(ps.stddev());
        System.out.println(ps.confidenceLo());
        System.out.println(ps.confidenceHi());

    }

}
